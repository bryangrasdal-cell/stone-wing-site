Stone Wing 0.9.1 build 93 — Mac Pro

Requirements: macOS 15 or later. Universal Apple silicon + Intel.

Fresh install: drag Stone Wing.app to Applications.

Stone Wing retains the existing Loom compatibility storage identity so upgrades preserve chats, settings, accounts, workspaces and routes. Do not remove ~/Library/Application Support/Loom or related Keychain items unless you intend to erase saved state.

Connect your own ChatGPT account inside Stone Wing. Computer Tools use Stone Wing's governed local and Bridge runtimes. Optional Local AI and optional services are only enabled by the user's choices.

Connected-computer features use per-install identities, explicit pairing, scoped authorization, and verified effects. A receiving computer must have a compatible Stone Wing receiver configured before remote computer work is available.

Recovery/update: quit Stone Wing before replacing the app. User state is not deleted automatically.
